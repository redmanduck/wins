Dimensions	3.18 x 3.75 inch
Area		11.925 inch^2
Number of copy	1